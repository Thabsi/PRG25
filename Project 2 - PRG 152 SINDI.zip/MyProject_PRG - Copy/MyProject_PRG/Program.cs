﻿using System;

namespace MyProject_PRG
{
    enum delivery
    {
        collect,
        delivery,
        exit

    }
    class Program
    {
        static void Main(string[] args)
        {
            input();
            bankDelivery();
            bankDeposit();
            end();
        }
        public static void input()
        {
            //string userInput;
            string fullName;
            string bankAccountNo;
            string company;
            double balance;
            int num;
            int pay;

            Console.WriteLine("The customer bank details");
            Console.Write("Your fullName: ");
            fullName = Console.ReadLine();
            Console.Write("Account number: ");
            bankAccountNo = Console.ReadLine();
            Console.Write("Balance amount in the account: ");
            balance = double.Parse(Console.ReadLine());

            

            Console.WriteLine("\n ----------ITEMS-------------");
            string[] items = new string[5];
            string Item;


            string[] Items = { "Wooden", "Chairs", "Bookshelves", "Shoerake", "Cutting board" };
            for (int i = 0; i < Items.Length; i++)
            {
                Console.WriteLine("The list of price [" + i + "] is: " + Items[i]);
            }

            Console.WriteLine("\n-------------------");
            double[] Price = { 2300, 2500, 1400, 170, 3100 };
            double total = 0;
            for (int i = 0; i < Price.Length; i++)
            {
                total += Price[i];
                Console.WriteLine("The list of price [" + i + "] is: " + Price[i]);
            }

            Console.WriteLine("The total is: " + total);

        }
        public static  void bankDelivery()
        {
            int userInput;
            delivery delivery;
            Console.WriteLine("which do you want to delivery");
            Console.WriteLine("select \n 1. collect \n 2. delivery");
            userInput = int.Parse(Console.ReadLine());
            delivery = (delivery)userInput;

            switch (delivery)
            {
                case delivery.collect:
                    Console.WriteLine("collect");
                    break;
                case delivery.delivery:
                    Console.WriteLine("delivery");
                    break;
                default:
                    Console.WriteLine("contiunte the process!");
                    break;
            }
            

            Console.WriteLine("select \n 1. cash \n 2. card");

            Console.WriteLine("\n------------BANK DEPOSIT----------");
            
        }
        public static void paymentBank(string names)
        {
            if (names == "")
            {
                Console.WriteLine("is cash payment");
                
            }
            else
            {
                Console.WriteLine("or card payment");
            }
        }
        public static void bankDeposit()
        {
            char deposit;
            do
            {
                Console.WriteLine("\nDo you want to deposit? (y/n)");
                deposit = Convert.ToChar(Console.ReadLine());
            } while (deposit == 'n');
            Console.WriteLine(" thank you ");

            Console.WriteLine("\n ---------PAYMENT--------");
            char pay;
            do
            {
                Console.WriteLine("FINIAL PAYMENT? (y/n)");
                pay = Convert.ToChar(Console.ReadLine());
            } while (pay == 'n');
            Console.WriteLine("PAYMENT SUCCESSFULL!!!");
        }
        public static void payFinial(int num, string items)
        {

           
        }
        public static void end()
        {
            Console.ReadLine();
        }
    }
}
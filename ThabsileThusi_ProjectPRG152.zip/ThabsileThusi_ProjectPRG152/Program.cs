﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace SportGames
{
    class Program
    {
        List<string> sportList = new List<string>();
        private string words;
        private object word;
        private object player1;
        private object player2;
        private object LeaveTheGames;
        //private string word;
        private string userWord;
        private int turnCount;
        private int player1Score;
        private int player2Score;
        string tShowBlankWord;
        string GuessLetters;
        public string Player1 { get; private set; }
        public string Player2 { get; private set; }
        public int Word { get; private set; }
        public int Rest { get; private set; }
        public object Score2 { get; private set; }
        public string TShowBlankWord { get => tShowBlankWord; set => tShowBlankWord = value; }
        public int Thecount { get; private set; }

        static void Main(string[] args)
        {
            string Player1, Player2;
            string words;
            int Word = 0;
            int player1Score = 0;
            int player2Score = 0;

        }
        public void PlayGame()
        {
            Console.WriteLine("Player 1, What is your name?");
            Player1 = Console.ReadLine();

            Console.WriteLine("Player 2, What is your name?");
            Player2 = Console.ReadLine();

            Console.WriteLine("{0}, What is the words", Player1);
            words = Console.ReadLine();
            Console.Clear();

            Console.WriteLine("Press Enter to continue...");
            Console.Clear();

            Word = words.Length;
            for (int i = 1; i <= Word; i++)
            {
                Console.Write("_\t");
            }
            Console.WriteLine(" ");

            for (int i = 1; i < 5; i++)
            {
                char guessWords = ' ';
                Console.WriteLine("This is guess number {0}", i + 1);
                Console.WriteLine("These are the letters you have already used: ");

                if (guessWords == ' ')
                {
                    Console.WriteLine("What letter do you guess");
                    guessWords = char.Parse(Console.ReadLine());
                }
                else
                {
                    Console.WriteLine("this is correct!");
                }
                Console.WriteLine("The letter is not part of the word");

                Console.ReadLine();
            }
        }
        public void StartGame()
        {
            PlayStory();
            string start = "Y";
            while (start == "Y")
            {
                Console.WriteLine("{0}, what is the word?", (int)GetPlayer());
                string win = Console.ReadLine().ToLower();
                Console.WriteLine("{0} How many score", (int)player1, (int)Score2);
                Console.WriteLine("{0} How many sore", (int)player2, (int)Score2);
                Console.WriteLine("Do u wnat to try again ?? (YES/NO)");
            }
            Console.WriteLine("THE WORD ARE THERE .");
            Console.WriteLine(words);
        }



        private void PlayStory()
        {
            throw new NotImplementedException();
        }
        private object GetPlayer()
        {
            throw new NotImplementedException();
        }
        public void EnterLetter(string word)
        {
            Console.WriteLine("\nThink of number{0}", (int)LeaveTheGames);
            this.ShowLetter();
            Console.WriteLine("think of lettter: ");
        }
        private void ShowLetter()
        {
            throw new NotImplementedException();
        }
        public void TheLetter(string ShowLetter)
        {
            Console.WriteLine("Press Enter to continue...");
            Console.ReadLine();
            if (string <= 7 && ShowLetter != string.Word)
            {
                this.ShowLetter();
                Console.WriteLine();
                Console.WriteLine();
            }

            else if (ShowLetter == userWord)
            {
                Console.WriteLine("enough word");
                Console.WriteLine("the word {0}", (string)ShowLetter);
                if (Thecount % 2 == 1)
                {
                    turnCount++;
                }
            }
        }
    }
}
